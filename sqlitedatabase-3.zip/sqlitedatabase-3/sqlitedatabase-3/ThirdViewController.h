//
//  ThirdViewController.h
//  sqlitedatabase-3
//
//  Created by Kumar on 02/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StudentClass.h"

@interface ThirdViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *sidText;
@property (weak, nonatomic) IBOutlet UITextField *snameText;

@property (weak, nonatomic) IBOutlet UITextField *saddressText;
@property (weak, nonatomic) IBOutlet UITextField *scourseText;
@property(nonatomic,retain)StudentClass *temp;
- (IBAction)pudateTable:(id)sender;
@end
