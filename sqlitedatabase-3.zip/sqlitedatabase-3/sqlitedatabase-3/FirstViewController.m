//
//  FirstViewController.m
//  sqlitedatabase-3
//
//  Created by Kumar on 02/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import "FirstViewController.h"
#import "SecondViewController.h"
#import "StudentClass.h"
#import "ThirdViewController.h"
#import "StudentClass.h"
#import <sqlite3.h>

@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _studentarray=[[NSMutableArray alloc]init];
    
    self.navigationItem.title=@"Table View";
    UIBarButtonItem *btn=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(gotoSecondController)];
    self.navigationItem.rightBarButtonItem=btn;
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    
    
    
}
-(void)gotoSecondController
{
    
    SecondViewController *s=[[SecondViewController alloc]init];
    
    s.temparray=_studentarray;
    [self.navigationController pushViewController:s animated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    // Return the number of rows in the section.
    return _studentarray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    StudentClass *stu=[_studentarray objectAtIndex:indexPath.row];
    cell.textLabel.text=stu.name;
    
    
    return cell;
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    [self.tableView reloadData];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ThirdViewController *third=[[ThirdViewController alloc]init];
    third.temp=[_studentarray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:third animated:YES];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    NSArray *dir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *dbpath=[NSString stringWithFormat:@"%@/studata.sqlite",[dir lastObject]];

    sqlite3 *db;
    sqlite3_stmt *mystmt;
    if(sqlite3_open([dbpath UTF8String], &db)==SQLITE_OK)
    {
        const char *query="select * from student";
        if(sqlite3_prepare(db, query, -1, &mystmt, NULL)==SQLITE_OK)
        {
            while(sqlite3_step(mystmt)==SQLITE_ROW)
            {
                int t1=sqlite3_column_int(mystmt, 0);
                NSString *t2=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 1)];
                 NSString *t3=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 2)];
                 NSString *t4=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 3)];
                
                StudentClass *s1=[[StudentClass alloc]init];
                s1.sid=t1;
                s1.name=t2;
                s1.address=t3;
                s1.course=t4;
                [_studentarray addObject:s1];
                //[super viewWillAppear:YES];
                //[self.tableView reloadData];

            }
        }
    }
}
@end
