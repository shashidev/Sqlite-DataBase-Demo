//
//  ThirdViewController.m
//  sqlitedatabase-3
//
//  Created by Kumar on 02/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import "ThirdViewController.h"
#import <sqlite3.h>
#import "FirstViewController.h"

@interface ThirdViewController ()

@end

@implementation ThirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _sidText.text=[NSString stringWithFormat:@"%i",_temp.sid];
    _snameText.text=_temp.name;
    _saddressText.text=_temp.address;
    _scourseText.text=_temp.course;
}

- (IBAction)pudateTable:(id)sender {
    
//    NSArray *dir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *dbpath=[NSString stringWithFormat:@"%@/studata.sqlite",[dir lastObject]];
//    
//    sqlite3 *db;
//    if(sqlite3_open([dbpath UTF8String], &db)==SQLITE_OK)
//    {
//        
//        NSString *q=[NSString stringWithFormat:@"insert into student values(\"%@\",\"%@\",\"%@\",\"%@\")",_sidText.text,_snameText.text,_saddressText.text,_scourseText.text];
//        
//        const char *query=[q UTF8String];
//        if(sqlite3_exec(db, query, NULL, NULL, NULL)==SQLITE_OK)
//        {
//            NSLog(@"Table Updated Successfully...!!");
//            
//            FirstViewController *f=[[FirstViewController alloc]init];
//            [self.navigationController pushViewController:f animated:YES];
//            
//        }
//        else
//        {
//            NSLog(@"Table udation failed...!!");
//        }
//        
//    }
//    else
//    {
//        NSLog(@"Database opening failed..!!");
//    }
//    sqlite3_close(db);
}
@end
