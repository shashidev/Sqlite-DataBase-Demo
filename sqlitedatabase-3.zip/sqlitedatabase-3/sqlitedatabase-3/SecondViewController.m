//
//  SecondViewController.m
//  sqlitedatabase-3
//
//  Created by Kumar on 02/11/15.
//  Copyright (c) 2015 Kumar. All rights reserved.
//

#import "SecondViewController.h"
#import <sqlite3.h>
#import "StudentClass.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)insertData:(id)sender {
    
    NSArray *dir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *dbpath=[NSString stringWithFormat:@"%@/studata.sqlite",[dir lastObject]];
    
    sqlite3 *db;
    
    if(sqlite3_open([dbpath UTF8String], &db)==SQLITE_OK)
    {
        /*Insert Data Into Table Student*/
        
        NSString *q=[NSString stringWithFormat:@"insert into student values(\"%@\",\"%@\",\"%@\",\"%@\")",_idTextField.text,_nameTextField.text,_addressTextField.text,_courseTextField.text];
        const char *query=[q UTF8String];
        if(sqlite3_exec(db, query, NULL, NULL, NULL)==SQLITE_OK)
        {
            NSLog(@"Data inserted into table Student..!!");
        }
        else
        {
            NSLog(@"Data insertion failed..!!!");
        }
    
        
        
        //Read Data From Table Student
        sqlite3 *db;
        sqlite3_stmt *mystmt;
        
        NSString *dbpath=[NSString stringWithFormat:@"%@/studata.sqlite",[dir lastObject]];
        if(sqlite3_open([dbpath UTF8String], &db)==SQLITE_OK)
        {
            const char *query="select * from student";
            
            if(sqlite3_prepare(db, query, -1, &mystmt, NULL)==SQLITE_OK)
            {
                while(sqlite3_step(mystmt)==SQLITE_ROW)
                {
                    int t1=sqlite3_column_int(mystmt, 0);
                    NSString *t2=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 1)];
                    NSString *t3=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 2)];
                    NSString *t4=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 3)];
                    
                    //NSLog(@"%i  %@   %@  %@",t1,t2,t3,t4);
                    
                    StudentClass *s1=[[StudentClass alloc]init];
                    s1.sid=t1;
                    s1.name=t2;
                    s1.address=t3;
                    s1.course=t4;
                    [_temparray addObject:s1];
                    [self.navigationController popViewControllerAnimated:YES];
                    
                }
            }
            else
            {
                NSLog(@"Prepration Statement Failed...!!!");
            }

        }
    }
    else
{
        NSLog(@"database Not opened..!");
    
    }
    sqlite3_close(db);
}
//- (IBAction)readData:(id)sender {
//    
//    NSArray *dir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    sqlite3 *db;
//    sqlite3_stmt *mystmt;
//    
//    NSString *dbpath=[NSString stringWithFormat:@"%@/studata.sqlite",[dir lastObject]];
//    if(sqlite3_open([dbpath UTF8String], &db)==SQLITE_OK)
//    {
//        const char *query="select * from student";
//        
//        if(sqlite3_prepare(db, query, -1, &mystmt, NULL)==SQLITE_OK)
//        {
//            while(sqlite3_step(mystmt)==SQLITE_ROW)
//            {
//            int t1=sqlite3_column_int(mystmt, 0);
//            NSString *t2=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 1)];
//            NSString *t3=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 2)];
//            NSString *t4=[NSString stringWithFormat:@"%s",sqlite3_column_text(mystmt, 3)];
//               
//                NSLog(@"%i  %@   %@  %@",t1,t2,t3,t4);
//                
//                StudentClass *s1=[[StudentClass alloc]init];
//                s1.sid=t1;
//                s1.name=t2;
//                s1.address=t3;
//                s1.course=t4;
//                [_temparray addObject:s1];
//                [self.navigationController popViewControllerAnimated:YES];
//                
//            }
//        }
//        
//    }
//}
@end
